
        var snowPlayers = [];
        var snowFlakes = document.querySelector('.snowfall');
//<div class="snow"></div>
        for(var i=0;i<300;i++)
          {
            var c = document.createElement('div');
            c.classList.add('snow');
            snowFlakes.appendChild(c);
          }
makeItSnow();


function lightUp(e) {
  e.preventDefault();
  document.body.classList.add('huzzah');
  if (snowPlayers.length && snowPlayers[0].playbackRate < 2) {
    snowPlayers.forEach(function(item) {
      item.playbackRate = item.playbackRate * 1.05;
    })
  }
}
function dim(e) {
  e.preventDefault();
  document.body.classList.remove('huzzah');
}

function makeItSnow() {
  var snows = document.querySelectorAll('.snow');
  
  if (!snows[0].animate) {
    return false;
  }

  for (var i = 0, len = snows.length; i < len; ++i) {
    var snowball = snows[i];
    var scale = Math.random() * .8 + .2;
    var player = snowball.animate([
      { transform: 'translate3d(' + (i/len*100) + 'vw,0,0) scale(' + scale + ')', opacity: scale },
      { transform: 'translate3d(' + (i/len*100 + 10) + 'vw,100vh,0) scale(' + scale + ')', opacity: scale }
    ], {
      duration: Math.random() * 3000 + 2000,
      iterations: Infinity,
      delay: -(Math.random() * 5000)
    });
    
    snowPlayers.push(player);
  }
}
        /**************************************/
       
         var loadSound = function () {
            var req = new XMLHttpRequest();
            req.open('GET', this.audioSrc, true);
            req.responseType = 'arraybuffer';


            req.onload = function () {

                    actx.decodeAudioData(req.response,playSound,onError);
            }

            req.send();
        };
        
        var playSound = function (buffer) {
             isPlaying = true;

            sourceNode.buffer = buffer;
            sourceNode.start(0);
            resetTimer();
            startTimer();
        };
        
        var resetTimer = function () {
            var time =  new Date(0, 0);
            duration = time.getTime();
        };

        var startTimer = function () {
        
            INTERVAL = setInterval(function () {
                if (isPlaying) {
                    var now = new Date(duration);
                    var sec = now.getMinutes();
                    duration = now.setMinutes(sec + 1);
                    animateLights();
                }
            }, 500);
        };
        
        var onError = function (e) {
            console.info('Error decoding audio file. -- ', e);
        };
        
        var setBufferSourceNode = function () {
            sourceNode = actx.createBufferSource();


                sourceNode.loop = true;

            sourceNode.connect(analyser);
            sourceNode.connect(actx.destination);

            sourceNode.onended = function () {
                clearInterval(INTERVAL);
                sourceNode.disconnect();
                resetTimer();
                isPlaying = false;
                sourceNode = actx.createBufferSource();
            }

        };

        
        var animateLights = function () {
 
        var freqJump = Math.floor(frequencyData.length);
        //console.log(this.frequencyData);
     
        for (var i = 0; i < lights.length; i++) {
            var l = lights[i];
            var lb = lightsBlur[i];
            var alfa = (i * 2 * Math.PI );
            var beta = (3 * 45) * Math.PI / 180;
         
           // console.log(Math.min(alfa,beta)/Math.max(alfa,beta));
            var lit = lightColors[getRandomInt(0,lightColors.length)];
            l.style['fill'] = lit;
            lb.style['fill'] = lit;
            //l.style['filter'] = "brightness("+Math.random(0.5,1)+(Math.min(alfa,beta)/Math.max(alfa,beta))+")";
           
            
            
        }
        
        
    };
        
        var getRandomInt = function(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
        
        var FFT_SIZE = 512;
        var audio = document.getElementById("musicAudio");
        var INTERVAL = null;
        var isPlaying = false;
        var duration = 0;
        var lights = document.querySelectorAll('.lights tspan');
        var lightsBlur = document.querySelectorAll('.lights-blur tspan');
        var lightColors = ['rgb(252, 45, 42)','rgb(52, 45, 242)','rgb(252, 245, 42)','rgb(52, 245, 42)','rgb(252, 45, 242)'];
        console.log(lights);
        try{
                window.AudioContext = window.AudioContext || window.webkitAudioContext;
                var actx = new window.AudioContext();
            } catch (e) {
            console.info('Web Audio API is not supported.', e);
        }
        
       
        var analyser = actx.createAnalyser();
        analyser.smoothingTimeConstant = 0.6;
        analyser.fftSize = FFT_SIZE;
        var bufferLength = analyser.frequencyBinCount;
        var frequencyData = new Uint8Array(bufferLength);
      
        
        var sourceNode = actx.createBufferSource();
    
        
        sourceNode.loop = true;
        
        
        sourceNode.connect(analyser);
        sourceNode.connect(actx.destination);    
        // Reduce the volume.
    

        this.sourceNode.onended = function () {
            clearInterval(INTERVAL);
            sourceNode.disconnect();
            resetTimer();
            isPlaying = false;
            sourceNode = actx.createBufferSource();
        }
        
        var audioSrc = audio.getAttribute('src');
        setBufferSourceNode();
        loadSound();